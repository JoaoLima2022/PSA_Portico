﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Inherits System.Windows.Forms.Form

    Dim Mx As New ACTMULTILib.ActEasyIF
    Dim dados_manual, dados_automatico, dados_velocidade1, dados_velocidadeH, dados_velocidadeAH, dados_pulsos, dados_encoder, posicao, dados_referencia, dados_pos1, dados_pos2, dados_pos3 As String
    Dim dados_posicao As Integer

    Dim cn As New MySqlConnection
    Dim cmd As New MySqlCommand
    Dim data_reader As MySqlDataReader

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Mx.ActLogicalStationNumber = 1
        Mx.Open()
        Me.Text = "Controlador"
        Btn_AH.Enabled = False
        Btn_H.Enabled = False
        Btn_parar.Enabled = False
        btVel_Lenta.Enabled = False
        btRefManual.Enabled = False

        btRefManual.Enabled = False
        txtPosicaoDest.Enabled = False
        btEnviar.Enabled = False
        txtPosicao1.Enabled = False
        txtPosicao2.Enabled = False
        txtPosicao3.Enabled = False
        btEnviarPosicao.Enabled = False

        '-----Ligar Base de Dados MySQL------------------------------
        cn.ConnectionString = "Server=localhost; User Id=root; 
        Database=controlo_ladder“

        Try
            If cn.State = ConnectionState.Closed Then
                cn.Open()
                MsgBox("Ligação Correcta à Base de Dados Controlo_Ladder")
            End If
        Catch ex As Exception
            cn.Close()
            MsgBox("Ligação Incorrecta à Base de Dados Controlo_Ladder")
        End Try
        cmd.Connection = cn
    End Sub



    Private Sub btModo_Click(sender As Object, e As EventArgs) Handles btModo.Click
        If btModo.Text = "Manual" Then
            btModo.Text = "Automático"
            Mx.WriteDeviceRandom("M0", 1, "1")
            Mx.ReadDeviceRandom("M0", 1, dados_manual)

            Mx.WriteDeviceRandom("M585", 1, "0")
            Mx.ReadDeviceRandom("M585", 1, dados_automatico)

            If dados_manual = "1" & dados_automatico = "0" Then
                ToolStripStatusLabelModo.Text = "Modo: Manual"

                Timer1.Enabled = True
                Timer1.Interval = 200
                Timer2.Enabled = False

                Btn_AH.Enabled = True
                Btn_H.Enabled = True
                Btn_parar.Enabled = True
                btVel_Lenta.Enabled = True
                btRefManual.Enabled = True
                btRefManual.Enabled = True

                txtPosicaoDest.Enabled = False
                btEnviar.Enabled = False
                txtPosicao1.Enabled = False
                txtPosicao2.Enabled = False
                txtPosicao3.Enabled = False
                btEnviarPosicao.Enabled = False
                ToolStripStatusLabelReferência.Text = "Referência Manual"

            Else
                ToolStripStatusLabelModo.Text = "Erro Modo Manual"
                Mx.WriteDeviceRandom("M0", 1, "0")
                Mx.ReadDeviceRandom("M0", 1, dados_manual)
                Timer1.Enabled = False
                Timer2.Enabled = False

                Btn_AH.Enabled = False
                Btn_H.Enabled = False
                Btn_parar.Enabled = False
                btVel_Lenta.Enabled = False
                btRefManual.Enabled = False
                btRefManual.Enabled = False

                txtPosicaoDest.Enabled = False
                btEnviar.Enabled = False
                txtPosicao1.Enabled = False
                txtPosicao2.Enabled = False
                txtPosicao3.Enabled = False
                btEnviarPosicao.Enabled = False
            End If



        Else
            btModo.Text = "Manual"
            Mx.WriteDeviceRandom("M0", 1, "0")
            Mx.ReadDeviceRandom("M0", 1, dados_manual)

            Mx.WriteDeviceRandom("M585", 1, "1")
            Mx.ReadDeviceRandom("M585", 1, dados_automatico)

            Mx.WriteDeviceRandom("M1", 1, "0")
            If dados_manual = "0" & dados_automatico = "1" Then
                ToolStripStatusLabelModo.Text = "Erro Modo automático"
                Mx.WriteDeviceRandom("M585", 1, "0")
                Mx.ReadDeviceRandom("M585", 1, dados_automatico)

                Timer1.Enabled = False
                Timer2.Enabled = False

                Btn_AH.Enabled = False
                Btn_H.Enabled = False
                Btn_parar.Enabled = False
                btVel_Lenta.Enabled = False
                btRefManual.Enabled = False

                txtPosicaoDest.Enabled = False
                btEnviar.Enabled = False
                txtPosicao1.Enabled = False
                txtPosicao2.Enabled = False
                txtPosicao3.Enabled = False
                btEnviarPosicao.Enabled = False

                txtPosicaoDest.Text = "0"
                txtPosicao1.Text = "0"
                txtPosicao2.Text = "0"
                txtPosicao3.Text = "0"
            Else
                ToolStripStatusLabelModo.Text = "Modo: Automático"
                ToolStripStatusLabelReferência.Text = "Referência Automática"

                Timer1.Enabled = True
                Timer1.Interval = 200
                Timer2.Enabled = True
                Timer2.Interval = 200

                Btn_AH.Enabled = False
                Btn_H.Enabled = False
                Btn_parar.Enabled = False
                btVel_Lenta.Enabled = False
                btRefManual.Enabled = False

                txtPosicaoDest.Enabled = True
                btEnviar.Enabled = True
                txtPosicao1.Enabled = True
                txtPosicao2.Enabled = True
                txtPosicao3.Enabled = True
                btEnviarPosicao.Enabled = True

                txtPosicaoDest.Text = "0"
                txtPosicao1.Text = "0"
                txtPosicao2.Text = "0"
                txtPosicao3.Text = "0"
            End If
        End If

    End Sub


    Private Sub btSair_Click(sender As Object, e As EventArgs) Handles btSair.Click
        Mx.WriteDeviceRandom("M0", 1, "0")
        Mx.WriteDeviceRandom("M1", 1, "0")
        Mx.WriteDeviceRandom("M2", 1, "0")
        Mx.WriteDeviceRandom("M3", 1, "0")
        Mx.WriteDeviceRandom("M50", 1, "0")
        Mx.WriteDeviceRandom("M56", 1, "0")
        Mx.WriteDeviceRandom("M585", 1, "0")
        End
    End Sub

    '-----MANUAL-------------
    'M2  - Ativa o relé para o motor rodar no sentido anti-horário
    'M3  - Ativa o relé para o motor rodar no sentido horário
    'M50 - Ativa velocidade lenta
    'M56 - Permite-nos estar após a referência no modo de contagem
    Private Sub Btn_parar_Click(sender As Object, e As EventArgs) Handles Btn_parar.Click
        Mx.WriteDeviceRandom("M2", 1, "0")
        Mx.ReadDeviceRandom("M2", 1, dados_velocidadeAH)
        Mx.WriteDeviceRandom("M3", 1, "0")
        Mx.ReadDeviceRandom("M3", 1, dados_velocidadeH)

        If dados_velocidadeH = "0" & dados_velocidadeAH = "0" Then
            ToolStripStatusLabelSentido.Text = "Parado!"
        End If

    End Sub

    Private Sub Btn_H_Click(sender As Object, e As EventArgs) Handles Btn_H.Click
        Mx.WriteDeviceRandom("M2", 1, "0")
        Mx.ReadDeviceRandom("M2", 1, dados_velocidadeAH)
        Mx.WriteDeviceRandom("M3", 1, "1")
        Mx.ReadDeviceRandom("M3", 1, dados_velocidadeH)

        Mx.ReadDeviceRandom("M1", 1, dados_referencia)

        If dados_velocidadeH = "1" & dados_velocidadeAH = "0" Then
            ToolStripStatusLabelSentido.Text = "Sentido Horário!"
            If dados_referencia = "0" Then
                ToolStripStatusLabelReferência.Text = "Referência Manual Desativada"
                ToolStripStatusLabelSentido.Text = "Parado!"
            End If
        Else
            Mx.WriteDeviceRandom("M2", 1, "0")
            Mx.WriteDeviceRandom("M3", 1, "0")
            ToolStripStatusLabelSentido.Text = "Parado!"
            If dados_referencia = "0" Then
                ToolStripStatusLabelReferência.Text = "Referência Manual Desativada"
                ToolStripStatusLabelSentido.Text = "Parado!"
            End If
        End If
    End Sub

    Private Sub Btn_AH_Click_1(sender As Object, e As EventArgs) Handles Btn_AH.Click
        Mx.WriteDeviceRandom("M2", 1, "1")
        Mx.ReadDeviceRandom("M2", 1, dados_velocidadeAH)
        Mx.WriteDeviceRandom("M3", 1, "0")
        Mx.ReadDeviceRandom("M3", 1, dados_velocidadeH)

        If dados_velocidadeH = "0" & dados_velocidadeAH = "1" Then
            ToolStripStatusLabelSentido.Text = "Sentido Anti-Horário!"
            If dados_referencia = "0" Then
                ToolStripStatusLabelReferência.Text = "Referência Manual Desativada"
                ToolStripStatusLabelSentido.Text = "Parado!"
            End If
        End If
    End Sub

    Private Sub btVel_Lenta_Click(sender As Object, e As EventArgs) Handles btVel_Lenta.Click
        Mx.ReadDeviceRandom("M50", 1, dados_velocidade1)
        If dados_velocidade1 = "0" And btVel_Lenta.Text = "Velocidade Rápida" Then
            btVel_Lenta.Text = "Velocidade Lenta"
            Mx.WriteDeviceRandom("M50", 1, "1")
            ToolStripStatusLabelVelocidade.Text = "Velocidade Lenta Ativada"
        Else
            Mx.WriteDeviceRandom("M50", 1, "0")
            ToolStripStatusLabelVelocidade.Text = "Velocidade Rápida Ativada"
            btVel_Lenta.Text = "Velocidade Rápida"
        End If
    End Sub

    Private Sub btRefManual_Click(sender As Object, e As EventArgs) Handles btRefManual.Click
        Mx.WriteDeviceRandom("M1", 1, "1")
        Mx.ReadDeviceRandom("M1", 1, dados_referencia)
        If dados_referencia = "1" Then
            ToolStripStatusLabelReferência.Text = "Referência Manual Ativada"
        Else
            ToolStripStatusLabelReferência.Text = "Referência Manual Desativada"
        End If
    End Sub

    '------------AUTOMÁTICO-----------------
    'M1  - Indica que estamos a colocar manualmente o motor na posição de referência
    'M56 - Permite-nos estar após a referência no modo de contagem
    'D10 - Valor de contagem ao encoder
    'D12 - Posição para onde queremos no motor associado ao encoder

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Mx.ReadDeviceRandom("D10", 1, dados_pulsos)
        dados_encoder=dados_pulsos-4200
        ToolStripStatusLabelContagem.Text = "Encoder:" + dados_encoder
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Mx.ReadDeviceRandom("M56", 1, posicao)
        ToolStripStatusLabelReferência.Text = "Referência Automática:" + posicao

        Mx.ReadDeviceRandom("M2", 1, dados_velocidadeAH)
        Mx.ReadDeviceRandom("M3", 1, dados_velocidadeH)

        If dados_velocidadeAH = "1" & dados_velocidadeH = "0" Then
            ToolStripStatusLabelReferência.Text = "Sentido Anti-Horário!"
        ElseIf dados_velocidadeAH = "0" & dados_velocidadeH = "1" Then
            ToolStripStatusLabelSentido.Text = "Sentido Horário!"
        Else
            ToolStripStatusLabelSentido.Text = "Parado!"
        End If

        Mx.ReadDeviceRandom("M50", 1, dados_velocidade1)
        If dados_velocidade1 = "0" Then
            ToolStripStatusLabelVelocidade.Text = "Velocidade Rápida!"
        Else
            ToolStripStatusLabelVelocidade.Text = "Velocidade Lenta!"
        End If
    End Sub

    Private Sub btEnviar_Click(sender As Object, e As EventArgs) Handles btEnviar.Click
        dados_posicao = CInt(txtPosicaoDest.Text + 4200)
        Mx.WriteDeviceRandom("D12", 1, dados_posicao)
        Mx.WriteDeviceRandom("M56", 1, "1")

        cmd.CommandText = "Insert into supervisao(PosMan) Values(" & dados_posicao & ")"
        cmd.ExecuteNonQuery()
    End Sub

    Private Sub btEnviarPosicao_Click(sender As Object, e As EventArgs) Handles btEnviarPosicao.Click
        'A posição de referência do encoder tem valor 4200
        dados_pos1 = CInt(txtPosicao1.Text + 4200)
        dados_pos2 = CInt(txtPosicao2.Text + 4200)
        dados_pos3 = CInt(txtPosicao3.Text + 4200)
        'Temos que impedir que os valores abaixo de -4200 não sejam introduzidos para o pórtico, porque o encoder apenas debita números entre 0-65530
        If txtPosicao1.Text < -4200 Or txtPosicao2.Text < -4200 Or txtPosicao3.Text < -4200 Then
            MessageBox.Show("Não se pode colocar valores menores que -4200")
        Else
            Mx.WriteDeviceRandom("D22", 1, dados_pos1) 'Ativa a Posição 1 do ciclo de posicionamento automático
            Mx.WriteDeviceRandom("D24", 1, dados_pos2) 'Ativa a Posição 2 do ciclo de posicionamento automático
            Mx.WriteDeviceRandom("D26", 1, dados_pos3) 'Ativa a Posição 3 do ciclo de posicionamento automático
            Mx.WriteDeviceRandom("M588", 1, "1") 'Arranca o ciclo automático

            'Enviamos os dados de posição para a base de dados
            cmd.CommandText = "Insert into supervisao(PosAut1,PosAut2,PosAut3) Values(" & dados_pos1 & "," & dados_pos2 & "," & dados_pos3 & ")"
            cmd.ExecuteNonQuery()
        End If
        txtPosicao1.Text = "0"
        txtPosicao2.Text = "0"
        txtPosicao3.Text = "0"
    End Sub
End Class
