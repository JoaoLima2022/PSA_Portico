﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btSair = New System.Windows.Forms.Button()
        Me.Btn_H = New System.Windows.Forms.Button()
        Me.Btn_parar = New System.Windows.Forms.Button()
        Me.btModo = New System.Windows.Forms.Button()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabelModo = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabelSentido = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabelVelocidade = New System.Windows.Forms.ToolStripStatusLabel()
        Me.btVel_Lenta = New System.Windows.Forms.Button()
        Me.StatusStrip2 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabelContagem = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabelReferência = New System.Windows.Forms.ToolStripStatusLabel()
        Me.txtPosicaoDest = New System.Windows.Forms.TextBox()
        Me.btRefManual = New System.Windows.Forms.Button()
        Me.btEnviar = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Btn_AH = New System.Windows.Forms.Button()
        Me.txtPosicao1 = New System.Windows.Forms.TextBox()
        Me.txtPosicao2 = New System.Windows.Forms.TextBox()
        Me.txtPosicao3 = New System.Windows.Forms.TextBox()
        Me.btEnviarPosicao = New System.Windows.Forms.Button()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.StatusStrip1.SuspendLayout()
        Me.StatusStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'btSair
        '
        Me.btSair.Location = New System.Drawing.Point(533, 240)
        Me.btSair.Name = "btSair"
        Me.btSair.Size = New System.Drawing.Size(72, 28)
        Me.btSair.TabIndex = 0
        Me.btSair.Text = "Sair"
        Me.btSair.UseVisualStyleBackColor = True
        '
        'Btn_H
        '
        Me.Btn_H.Location = New System.Drawing.Point(166, 111)
        Me.Btn_H.Name = "Btn_H"
        Me.Btn_H.Size = New System.Drawing.Size(72, 38)
        Me.Btn_H.TabIndex = 2
        Me.Btn_H.Text = "Sentido Horário"
        Me.Btn_H.UseVisualStyleBackColor = True
        '
        'Btn_parar
        '
        Me.Btn_parar.Location = New System.Drawing.Point(89, 111)
        Me.Btn_parar.Name = "Btn_parar"
        Me.Btn_parar.Size = New System.Drawing.Size(72, 38)
        Me.Btn_parar.TabIndex = 7
        Me.Btn_parar.Text = "Parar"
        Me.Btn_parar.UseVisualStyleBackColor = True
        '
        'btModo
        '
        Me.btModo.Location = New System.Drawing.Point(274, 24)
        Me.btModo.Name = "btModo"
        Me.btModo.Size = New System.Drawing.Size(75, 23)
        Me.btModo.TabIndex = 9
        Me.btModo.Text = "Manual"
        Me.btModo.UseVisualStyleBackColor = True
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabelModo, Me.ToolStripStatusLabelSentido, Me.ToolStripStatusLabelVelocidade})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 293)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(617, 22)
        Me.StatusStrip1.TabIndex = 15
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabelModo
        '
        Me.ToolStripStatusLabelModo.Name = "ToolStripStatusLabelModo"
        Me.ToolStripStatusLabelModo.Size = New System.Drawing.Size(39, 17)
        Me.ToolStripStatusLabelModo.Text = "Modo"
        '
        'ToolStripStatusLabelSentido
        '
        Me.ToolStripStatusLabelSentido.Name = "ToolStripStatusLabelSentido"
        Me.ToolStripStatusLabelSentido.Size = New System.Drawing.Size(47, 17)
        Me.ToolStripStatusLabelSentido.Text = "Sentido"
        '
        'ToolStripStatusLabelVelocidade
        '
        Me.ToolStripStatusLabelVelocidade.Name = "ToolStripStatusLabelVelocidade"
        Me.ToolStripStatusLabelVelocidade.Size = New System.Drawing.Size(64, 17)
        Me.ToolStripStatusLabelVelocidade.Text = "Velocidade"
        '
        'btVel_Lenta
        '
        Me.btVel_Lenta.Location = New System.Drawing.Point(46, 172)
        Me.btVel_Lenta.Name = "btVel_Lenta"
        Me.btVel_Lenta.Size = New System.Drawing.Size(72, 38)
        Me.btVel_Lenta.TabIndex = 16
        Me.btVel_Lenta.Text = "Velocidade Lenta"
        Me.btVel_Lenta.UseVisualStyleBackColor = True
        '
        'StatusStrip2
        '
        Me.StatusStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabelContagem, Me.ToolStripStatusLabelReferência})
        Me.StatusStrip2.Location = New System.Drawing.Point(0, 271)
        Me.StatusStrip2.Name = "StatusStrip2"
        Me.StatusStrip2.Size = New System.Drawing.Size(617, 22)
        Me.StatusStrip2.TabIndex = 17
        Me.StatusStrip2.Text = "StatusStrip2"
        '
        'ToolStripStatusLabelContagem
        '
        Me.ToolStripStatusLabelContagem.Name = "ToolStripStatusLabelContagem"
        Me.ToolStripStatusLabelContagem.Size = New System.Drawing.Size(63, 17)
        Me.ToolStripStatusLabelContagem.Text = "Contagem"
        '
        'ToolStripStatusLabelReferência
        '
        Me.ToolStripStatusLabelReferência.Name = "ToolStripStatusLabelReferência"
        Me.ToolStripStatusLabelReferência.Size = New System.Drawing.Size(62, 17)
        Me.ToolStripStatusLabelReferência.Text = "Referencia"
        '
        'txtPosicaoDest
        '
        Me.txtPosicaoDest.Location = New System.Drawing.Point(410, 119)
        Me.txtPosicaoDest.Name = "txtPosicaoDest"
        Me.txtPosicaoDest.Size = New System.Drawing.Size(100, 20)
        Me.txtPosicaoDest.TabIndex = 20
        Me.txtPosicaoDest.Text = "txtPosicaoDest"
        '
        'btRefManual
        '
        Me.btRefManual.Location = New System.Drawing.Point(136, 172)
        Me.btRefManual.Name = "btRefManual"
        Me.btRefManual.Size = New System.Drawing.Size(75, 38)
        Me.btRefManual.TabIndex = 21
        Me.btRefManual.Text = "Referência Manual"
        Me.btRefManual.UseVisualStyleBackColor = True
        '
        'btEnviar
        '
        Me.btEnviar.Location = New System.Drawing.Point(516, 119)
        Me.btEnviar.Name = "btEnviar"
        Me.btEnviar.Size = New System.Drawing.Size(75, 23)
        Me.btEnviar.TabIndex = 22
        Me.btEnviar.Text = "Enviar"
        Me.btEnviar.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        '
        'Btn_AH
        '
        Me.Btn_AH.Location = New System.Drawing.Point(12, 111)
        Me.Btn_AH.Name = "Btn_AH"
        Me.Btn_AH.Size = New System.Drawing.Size(72, 38)
        Me.Btn_AH.TabIndex = 23
        Me.Btn_AH.Text = "Sentido Anti-Horário"
        Me.Btn_AH.UseVisualStyleBackColor = True
        '
        'txtPosicao1
        '
        Me.txtPosicao1.Location = New System.Drawing.Point(410, 160)
        Me.txtPosicao1.Name = "txtPosicao1"
        Me.txtPosicao1.Size = New System.Drawing.Size(100, 20)
        Me.txtPosicao1.TabIndex = 24
        Me.txtPosicao1.Text = "txtPosicao1"
        '
        'txtPosicao2
        '
        Me.txtPosicao2.Location = New System.Drawing.Point(410, 190)
        Me.txtPosicao2.Name = "txtPosicao2"
        Me.txtPosicao2.Size = New System.Drawing.Size(100, 20)
        Me.txtPosicao2.TabIndex = 25
        Me.txtPosicao2.Text = "txtPosicao2"
        '
        'txtPosicao3
        '
        Me.txtPosicao3.Location = New System.Drawing.Point(410, 216)
        Me.txtPosicao3.Name = "txtPosicao3"
        Me.txtPosicao3.Size = New System.Drawing.Size(100, 20)
        Me.txtPosicao3.TabIndex = 26
        Me.txtPosicao3.Text = "txtPosicao3"
        '
        'btEnviarPosicao
        '
        Me.btEnviarPosicao.Location = New System.Drawing.Point(516, 172)
        Me.btEnviarPosicao.Name = "btEnviarPosicao"
        Me.btEnviarPosicao.Size = New System.Drawing.Size(75, 48)
        Me.btEnviarPosicao.TabIndex = 27
        Me.btEnviarPosicao.Text = "Iniciar Posição Automática"
        Me.btEnviarPosicao.UseVisualStyleBackColor = True
        '
        'Timer2
        '
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(617, 315)
        Me.Controls.Add(Me.btEnviarPosicao)
        Me.Controls.Add(Me.txtPosicao3)
        Me.Controls.Add(Me.txtPosicao2)
        Me.Controls.Add(Me.txtPosicao1)
        Me.Controls.Add(Me.Btn_AH)
        Me.Controls.Add(Me.btEnviar)
        Me.Controls.Add(Me.btRefManual)
        Me.Controls.Add(Me.txtPosicaoDest)
        Me.Controls.Add(Me.StatusStrip2)
        Me.Controls.Add(Me.btVel_Lenta)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.btModo)
        Me.Controls.Add(Me.Btn_parar)
        Me.Controls.Add(Me.Btn_H)
        Me.Controls.Add(Me.btSair)
        Me.Name = "Form1"
        Me.Text = "Controlador"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.StatusStrip2.ResumeLayout(False)
        Me.StatusStrip2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btSair As Button
    Friend WithEvents Btn_H As Button
    Friend WithEvents Btn_parar As Button
    Friend WithEvents btModo As Button
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabelModo As ToolStripStatusLabel
    Friend WithEvents btVel_Lenta As Button
    Friend WithEvents ToolStripStatusLabelSentido As ToolStripStatusLabel
    Friend WithEvents StatusStrip2 As StatusStrip
    Friend WithEvents ToolStripStatusLabelContagem As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabelReferência As ToolStripStatusLabel
    Friend WithEvents txtPosicaoDest As TextBox
    Friend WithEvents btRefManual As Button
    Friend WithEvents btEnviar As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Btn_AH As Button
    Friend WithEvents txtPosicao1 As TextBox
    Friend WithEvents txtPosicao2 As TextBox
    Friend WithEvents txtPosicao3 As TextBox
    Friend WithEvents btEnviarPosicao As Button
    Friend WithEvents Timer2 As Timer
    Friend WithEvents ToolStripStatusLabelVelocidade As ToolStripStatusLabel
End Class
